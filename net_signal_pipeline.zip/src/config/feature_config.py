
# ============================================================
# Configuration
# ============================================================
HDFS_NAMENODE = 'hdfs://njbbepapa1.nss.vzwnet.com:9000'
BASE_DIR = "/user/kovvuve/owl_history_v3/date="
TIME_COL = "time"
LOOKBACK_HOURS = 24 # Number of hours to look back for data ingestions
feature_groups = {
    "signal_quality": ["4GRSRP", "4GRSRQ", "SNR", "4GSignal", "BRSRP", "RSRQ", "5GSNR", "CQI"],
    "throughput_data": [
        #"LTEPDSCHPeakThroughput", "LTEPDSCHThroughput",
        #"LTEPUSCHPeakThroughput", "LTEPUSCHThroughput",
        #"5GNRPDSCHThroughput", "5GNRPUSCHThroughput",
        #"5GNRPDSCHPeakThroughput", "5GNRPUSCHPeakThroughput",
        #"TxPDCPBytes", "RxPDCPBytes",
        "TotalBytesReceived", "TotalBytesSent",
        "TotalPacketReceived", "TotalPacketSent"


    ],
}
ALL_FEATURES = feature_groups["signal_quality"] + feature_groups["throughput_data"]
ZERO_LIST = ["RSRQ", "4GRSRQ", "4GRSRP", "BRSRP"]

# ===== Global Config for Parameters =====
PARAMS_KDE_EWMA = {
    "min_training_points": 10,
    "filter_percentile": 99,
    "threshold_percentile": 99,
    "anomaly_direction": "low",
    "recent_window_size": 1,
    "window": 100,
    "no_of_stds": 3.0,
    "n_shift": 1,
    "scaler": None,
    "min_std_ratio": 0.01,
    "use_weighted_std": False,
}
